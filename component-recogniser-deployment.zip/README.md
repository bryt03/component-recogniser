# Component Recogniser

This is a real-time electronic component identification web application powered by Teachable Machine and ml5.js. It uses your webcam feed to classify components based on a pre-trained Teachable Machine model.

## Features

*   **Real-time Classification**: Identifies components from your webcam feed.
*   **Custom Model Support**: Easily switch between different Teachable Machine models by pasting their URLs.
*   **Confidence Scores**: Displays the confidence level for each classification.
*   **Enhanced UI**: A clean, dark-themed interface with clear status indicators.
*   **Developer Integration Guide**: Includes an in-depth guide on how to integrate this functionality into larger web applications (React, Vue, headless mode, backend integration).

## Local Setup

To run this application locally:

1.  **Download the files**: Get the `index.html` and `developer_integration_content.html` files.
2.  **Navigate to the directory**: Open your terminal or command prompt and navigate to the directory where you saved the files.
3.  **Start a local web server**: You can use Python's built-in HTTP server:
    ```bash
    python3 -m http.server 8080
    ```
4.  **Open in browser**: Open your web browser and go to `http://localhost:8080`.

## Deployment to GitHub Pages

Follow these steps to host your Component Recogniser on GitHub Pages and get a shareable link:

### Prerequisites

*   A GitHub account.
*   Git installed on your local machine.

### Steps

1.  **Create a New GitHub Repository**:
    *   Go to [github.com/new](https://github.com/new).
    *   Give your repository a name (e.g., `component-recogniser`).
    *   Choose `Public` (GitHub Pages only works with public repositories for free).
    *   **Do NOT** initialize with a README, .gitignore, or license.
    *   Click `Create repository`.

2.  **Initialize a Local Git Repository**:
    *   Open your terminal or command prompt.
    *   Navigate to the directory containing your `index.html` and `developer_integration_content.html` files.
    *   Initialize a new Git repository:
        ```bash
        git init
        ```

3.  **Add Your Files**:
    *   Add all the project files to the repository:
        ```bash
        git add .
        ```

4.  **Commit Your Changes**:
    *   Commit the files with a message:
        ```bash
        git commit -m "Initial commit of Component Recogniser app"
        ```

5.  **Link to GitHub and Push**:
    *   Connect your local repository to the one you created on GitHub. Replace `YOUR_USERNAME` and `YOUR_REPOSITORY_NAME` with your actual GitHub username and repository name:
        ```bash
        git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY_NAME.git
        git branch -M main
        git push -u origin main
        ```

6.  **Enable GitHub Pages**:
    *   Go to your repository on GitHub (e.g., `https://github.com/YOUR_USERNAME/YOUR_REPOSITORY_NAME`).
    *   Click on the `Settings` tab.
    *   In the left sidebar, click on `Pages`.
    *   Under "Build and deployment", for "Source", select `Deploy from a branch`.
    *   For "Branch", select `main` (or `master` if that's what you used) and choose the `/ (root)` folder.
    *   Click `Save`.

7.  **Access Your Live Website**:
    *   GitHub Pages will now build and deploy your site. This usually takes a few minutes.
    *   Refresh the `Pages` settings page after a few minutes. You will see a message like "Your site is live at `https://YOUR_USERNAME.github.io/YOUR_REPOSITORY_NAME/`".
    *   Click on this link to view your live Component Recogniser app!

## Using Your Own Teachable Machine Model

1.  Go to [teachablemachine.withgoogle.com](https://teachablemachine.withgoogle.com), train an image model, and click **Export Model → Upload (shareable link)**.
2.  Copy the URL (e.g., `https://teachablemachine.withgoogle.com/models/ABC123/`).
3.  Paste it into the **Teachable Machine Model URL** field in the deployed app and click **Load Model**.

## Developer Integration

For guidance on integrating this Component Recogniser into larger web applications (e.g., React, Vue, or backend systems), refer to the `developer_integration_content.html` file included in this project. It provides code snippets and architectural recommendations for modular integration.
